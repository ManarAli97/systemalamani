

<br>
<div class="row align-items-center">
    <div class="col">
        <span></span>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php  echo url.'/'.$this->folder?>"><?php  echo $this->langControl('main_log_accountant') ?> </a></li>
                <li class="breadcrumb-item">  عرض المحاسبين  </li>
            </ol>
        </nav>

    </div>

</div>

