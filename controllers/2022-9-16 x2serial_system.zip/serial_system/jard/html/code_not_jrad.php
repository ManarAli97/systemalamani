<tbody class="listCode">

<?php  foreach ($data as $out) {  ?>
<tr>
        <td>  <?php echo $id_page ?> </td>
        <td>  <?php  echo $out['code']  ?></td>
        <td>   </td>
        <td>      </td>
        <td>   </td>
        <td>     </td>
        <td>  </td>
        <td>  </td>

 
    </tr>
<?php }  ?>
 </tbody>