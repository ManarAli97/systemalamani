
<title> Hello baby</title>

<br>
<br>
<div class="name_app">

    <?php  echo  $msg ?>
</div>

<style>
    .name_app {
        text-align: center;
        font-size: 54px;
        font-weight: bold;
        text-shadow: 3px 4px 2px #CDDC39;
        background: #FF5722;
        padding: 13px 6px;
        border-bottom: 2px solid #E91E63;
        box-shadow: 3px 5px 13px #FFEB3B;
    }
    body
    {
        background: #000000;
    }

</style>
<br>
<br>