
<div class="container">
    <div class="row">
        <div class="col-lg-3">

            <div class="menu_category">



                <div id="accordion">
                    <div class="card row_accordion main_catg">

                        <div class="card-header" id="heading-1">

                            <div class="row justify-content-between align-items-center">
                                <div class="col-8">
                                    <a  class="list_link" href="#" >
                                        <div class="row align-items-center">
                                            <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                            <div class="col-8" style="padding-right: 3px" > موبايل </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-auto">
                                    <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-1" aria-expanded="false" aria-controls="collapse-1">
                                        <i class="fa fa-caret-left"></i>
                                    </button>
                                </div>
                            </div>

                            <div id="collapse-1" class="collapse" data-parent="#accordion" aria-labelledby="heading-1">
                                <div class="card-body">

                                    <div id="accordion-1">
                                        <div class="card row_accordion">
                                            <div class="card-header" id="heading-1-1">
                                                <div class="row justify-content-between align-items-center">
                                                    <div class="col-8">
                                                        <a  class="list_link" href="#" >
                                                            <div class="row align-items-center">
                                                                <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                <div class="col-8" style="padding-right: 3px" >  ايفون </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="col-4">
                                                        <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-1-1" aria-expanded="false" aria-controls="collapse-1-1">
                                                            <i class="fa fa-caret-left"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                                <div id="collapse-1-1" class="collapse" data-parent="#accordion-1" aria-labelledby="heading-1-1">
                                                    <div class="card-body">

                                                        <div id="accordion-1-1">
                                                            <div class="card row_accordion">
                                                                <div class="card-header" id="heading-1-1-1">
                                                                    <div class="row justify-content-between align-items-center">
                                                                        <div class="col-8">
                                                                            <a  class="list_link" href="#" >
                                                                                <div class="row align-items-center">
                                                                                    <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                    <div class="col-8" style="padding-right: 3px" > 1 </div>
                                                                                </div>
                                                                            </a>
                                                                        </div>
                                                                        <div class="col-4">
                                                                            <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-1-1-1" aria-expanded="false" aria-controls="collapse-1-1-1">
                                                                                <i class="fa fa-caret-left"></i>
                                                                            </button>
                                                                        </div>
                                                                    </div>

                                                                    <div id="collapse-1-1-1" class="collapse" data-parent="#accordion-1-1" aria-labelledby="heading-1-1-1">
                                                                        <div class="card-body">

                                                                            <div class="card row_accordion">
                                                                                <div class="card-header" >
                                                                                    <div class="row justify-content-between align-items-center">
                                                                                        <div class="col-12">
                                                                                            <a  class="list_link" href="#" >
                                                                                                <div class="row align-items-center">
                                                                                                    <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                                    <div class="col-8" style="padding-right: 3px" >  last -cat </div>
                                                                                                </div>
                                                                                            </a>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="card row_accordion">
                                                                <div class="card-header" id="heading-1-1-2">

                                                                    <div class="row justify-content-between align-items-center">
                                                                        <div class="col-8">
                                                                            <a  class="list_link" href="#" >
                                                                                <div class="row align-items-center">
                                                                                    <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                    <div class="col-8" style="padding-right: 3px" > 2 </div>
                                                                                </div>
                                                                            </a>
                                                                        </div>
                                                                        <div class="col-4">
                                                                            <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-1-1-2" aria-expanded="false" aria-controls="collapse-1-1-2">
                                                                                <i class="fa fa-caret-left"></i>
                                                                            </button>
                                                                        </div>
                                                                    </div>



                                                                    <div id="collapse-1-1-2" class="collapse" data-parent="#accordion-1-1" aria-labelledby="heading-1-1-2">
                                                                        <div class="card-body">

                                                                            <div class="card row_accordion">
                                                                                <div class="card-header" >
                                                                                    <div class="row justify-content-between align-items-center">
                                                                                        <div class="col-12">
                                                                                            <a  class="list_link" href="#" >
                                                                                                <div class="row align-items-center">
                                                                                                    <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                                    <div class="col-8" style="padding-right: 3px" >  last -cat </div>
                                                                                                </div>
                                                                                            </a>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                        <div class="card row_accordion">
                                            <div class="card-header" id="heading-1-2">

                                                <div class="row justify-content-between align-items-center">
                                                    <div class="col-8">
                                                        <a  class="list_link" href="#" >
                                                            <div class="row align-items-center">
                                                                <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                <div class="col-8" style="padding-right: 3px" >  سامسونك </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="col-4">
                                                        <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-1-2" aria-expanded="false" aria-controls="collapse-1-2">
                                                            <i class="fa fa-caret-left"></i>
                                                        </button>
                                                    </div>
                                                </div>


                                                <div id="collapse-1-2" class="collapse" data-parent="#accordion-1" aria-labelledby="heading-1-2">
                                                    <div class="card-body">

                                                        <div class="card row_accordion">
                                                            <div class="card-header" >
                                                                <div class="row justify-content-between align-items-center">
                                                                    <div class="col-12">
                                                                        <a  class="list_link" href="#" >
                                                                            <div class="row align-items-center">
                                                                                <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                <div class="col-8" style="padding-right: 3px" >  last -cat </div>
                                                                            </div>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="card row_accordion main_catg">

                        <div class="card-header" id="heading-2">

                            <div class="row justify-content-between align-items-center">
                                <div class="col-8">
                                    <a  class="list_link" href="#" >
                                        <div class="row align-items-center">
                                            <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                            <div class="col-8" style="padding-right: 3px" > اكسسورارت </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-auto">
                                    <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-2" aria-expanded="false" aria-controls="collapse-2">
                                        <i class="fa fa-caret-left"></i>
                                    </button>
                                </div>
                            </div>

                            <div id="collapse-2" class="collapse" data-parent="#accordion" aria-labelledby="heading-2">
                                <div class="card-body">

                                    <div id="accordion-2">
                                        <div class="card row_accordion">
                                            <div class="card-header" id="heading-2-2">
                                                <div class="row justify-content-between align-items-center">
                                                    <div class="col-8">
                                                        <a  class="list_link" href="#" >
                                                            <div class="row align-items-center">
                                                                <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                <div class="col-8" style="padding-right: 3px" >  ايفون </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="col-4">
                                                        <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-2-2" aria-expanded="false" aria-controls="collapse-2-2">
                                                            <i class="fa fa-caret-left"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                                <div id="collapse-2-2" class="collapse" data-parent="#accordion-2" aria-labelledby="heading-2-2">
                                                    <div class="card-body">

                                                        <div id="accordion-2-2">
                                                            <div class="card row_accordion">
                                                                <div class="card-header" id="heading-2-2-2">
                                                                    <div class="row justify-content-between align-items-center">
                                                                        <div class="col-8">
                                                                            <a  class="list_link" href="#" >
                                                                                <div class="row align-items-center">
                                                                                    <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                    <div class="col-8" style="padding-right: 3px" > 2 </div>
                                                                                </div>
                                                                            </a>
                                                                        </div>
                                                                        <div class="col-4">
                                                                            <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-2-2-2" aria-expanded="false" aria-controls="collapse-2-2-2">
                                                                                <i class="fa fa-caret-left"></i>
                                                                            </button>
                                                                        </div>
                                                                    </div>

                                                                    <div id="collapse-2-2-2" class="collapse" data-parent="#accordion-2-2" aria-labelledby="heading-2-2-2">
                                                                        <div class="card-body">

                                                                            <div class="card row_accordion">
                                                                                <div class="card-header" >
                                                                                    <div class="row justify-content-between align-items-center">
                                                                                        <div class="col-12">
                                                                                            <a  class="list_link" href="#" >
                                                                                                <div class="row align-items-center">
                                                                                                    <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                                    <div class="col-8" style="padding-right: 3px" >  last -cat </div>
                                                                                                </div>
                                                                                            </a>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="card row_accordion">
                                                                <div class="card-header" id="heading-2-2-2">

                                                                    <div class="row justify-content-between align-items-center">
                                                                        <div class="col-8">
                                                                            <a  class="list_link" href="#" >
                                                                                <div class="row align-items-center">
                                                                                    <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                    <div class="col-8" style="padding-right: 3px" > 2 </div>
                                                                                </div>
                                                                            </a>
                                                                        </div>
                                                                        <div class="col-4">
                                                                            <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-2-2-2" aria-expanded="false" aria-controls="collapse-2-2-2">
                                                                                <i class="fa fa-caret-left"></i>
                                                                            </button>
                                                                        </div>
                                                                    </div>



                                                                    <div id="collapse-2-2-2" class="collapse" data-parent="#accordion-2-2" aria-labelledby="heading-2-2-2">
                                                                        <div class="card-body">

                                                                            <div class="card row_accordion">
                                                                                <div class="card-header" >
                                                                                    <div class="row justify-content-between align-items-center">
                                                                                        <div class="col-12">
                                                                                            <a  class="list_link" href="#" >
                                                                                                <div class="row align-items-center">
                                                                                                    <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                                    <div class="col-8" style="padding-right: 3px" >  last -cat </div>
                                                                                                </div>
                                                                                            </a>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                        <div class="card row_accordion">
                                            <div class="card-header" id="heading-2-2">

                                                <div class="row justify-content-between align-items-center">
                                                    <div class="col-8">
                                                        <a  class="list_link" href="#" >
                                                            <div class="row align-items-center">
                                                                <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                <div class="col-8" style="padding-right: 3px" >  سامسونك </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="col-4">
                                                        <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-2-2" aria-expanded="false" aria-controls="collapse-2-2">
                                                            <i class="fa fa-caret-left"></i>
                                                        </button>
                                                    </div>
                                                </div>


                                                <div id="collapse-2-2" class="collapse" data-parent="#accordion-2" aria-labelledby="heading-2-2">
                                                    <div class="card-body">

                                                        <div class="card row_accordion">
                                                            <div class="card-header" >
                                                                <div class="row justify-content-between align-items-center">
                                                                    <div class="col-12">
                                                                        <a  class="list_link" href="#" >
                                                                            <div class="row align-items-center">
                                                                                <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                <div class="col-8" style="padding-right: 3px" >  last -cat </div>
                                                                            </div>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card row_accordion main_catg">

                        <div class="card-header" id="heading-3">

                            <div class="row justify-content-between align-items-center">
                                <div class="col-8">
                                    <a  class="list_link" href="#" >
                                        <div class="row align-items-center">
                                            <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                            <div class="col-8" style="padding-right: 3px" > اجهزة ملحقة </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-auto">
                                    <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-3" aria-expanded="false" aria-controls="collapse-3">
                                        <i class="fa fa-caret-left"></i>
                                    </button>
                                </div>
                            </div>

                            <div id="collapse-3" class="collapse" data-parent="#accordion" aria-labelledby="heading-3">
                                <div class="card-body">

                                    <div id="accordion-3">
                                        <div class="card row_accordion">
                                            <div class="card-header" id="heading-3-3">
                                                <div class="row justify-content-between align-items-center">
                                                    <div class="col-8">
                                                        <a  class="list_link" href="#" >
                                                            <div class="row align-items-center">
                                                                <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                <div class="col-8" style="padding-right: 3px" >  ايفون </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="col-4">
                                                        <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-3-3" aria-expanded="false" aria-controls="collapse-3-3">
                                                            <i class="fa fa-caret-left"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                                <div id="collapse-3-3" class="collapse" data-parent="#accordion-3" aria-labelledby="heading-3-3">
                                                    <div class="card-body">

                                                        <div id="accordion-3-3">
                                                            <div class="card row_accordion">
                                                                <div class="card-header" id="heading-3-3-3">
                                                                    <div class="row justify-content-between align-items-center">
                                                                        <div class="col-8">
                                                                            <a  class="list_link" href="#" >
                                                                                <div class="row align-items-center">
                                                                                    <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                    <div class="col-8" style="padding-right: 3px" > 3 </div>
                                                                                </div>
                                                                            </a>
                                                                        </div>
                                                                        <div class="col-4">
                                                                            <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-3-3-3" aria-expanded="false" aria-controls="collapse-3-3-3">
                                                                                <i class="fa fa-caret-left"></i>
                                                                            </button>
                                                                        </div>
                                                                    </div>

                                                                    <div id="collapse-3-3-3" class="collapse" data-parent="#accordion-3-3" aria-labelledby="heading-3-3-3">
                                                                        <div class="card-body">

                                                                            <div class="card row_accordion">
                                                                                <div class="card-header" >
                                                                                    <div class="row justify-content-between align-items-center">
                                                                                        <div class="col-12">
                                                                                            <a  class="list_link" href="#" >
                                                                                                <div class="row align-items-center">
                                                                                                    <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                                    <div class="col-8" style="padding-right: 3px" >  last -cat </div>
                                                                                                </div>
                                                                                            </a>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="card row_accordion">
                                                                <div class="card-header" id="heading-3-3-3">

                                                                    <div class="row justify-content-between align-items-center">
                                                                        <div class="col-8">
                                                                            <a  class="list_link" href="#" >
                                                                                <div class="row align-items-center">
                                                                                    <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                    <div class="col-8" style="padding-right: 3px" > 3 </div>
                                                                                </div>
                                                                            </a>
                                                                        </div>
                                                                        <div class="col-4">
                                                                            <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-3-3-3" aria-expanded="false" aria-controls="collapse-3-3-3">
                                                                                <i class="fa fa-caret-left"></i>
                                                                            </button>
                                                                        </div>
                                                                    </div>



                                                                    <div id="collapse-3-3-3" class="collapse" data-parent="#accordion-3-3" aria-labelledby="heading-3-3-3">
                                                                        <div class="card-body">

                                                                            <div class="card row_accordion">
                                                                                <div class="card-header" >
                                                                                    <div class="row justify-content-between align-items-center">
                                                                                        <div class="col-12">
                                                                                            <a  class="list_link" href="#" >
                                                                                                <div class="row align-items-center">
                                                                                                    <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                                    <div class="col-8" style="padding-right: 3px" >  last -cat </div>
                                                                                                </div>
                                                                                            </a>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                        <div class="card row_accordion">
                                            <div class="card-header" id="heading-3-3">

                                                <div class="row justify-content-between align-items-center">
                                                    <div class="col-8">
                                                        <a  class="list_link" href="#" >
                                                            <div class="row align-items-center">
                                                                <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                <div class="col-8" style="padding-right: 3px" >  سامسونك </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="col-4">
                                                        <button class="btn btn_open_accordion collapsed"   data-toggle="collapse" href="#collapse-3-3" aria-expanded="false" aria-controls="collapse-3-3">
                                                            <i class="fa fa-caret-left"></i>
                                                        </button>
                                                    </div>
                                                </div>


                                                <div id="collapse-3-3" class="collapse" data-parent="#accordion-3" aria-labelledby="heading-3-3">
                                                    <div class="card-body">

                                                        <div class="card row_accordion">
                                                            <div class="card-header" >
                                                                <div class="row justify-content-between align-items-center">
                                                                    <div class="col-12">
                                                                        <a  class="list_link" href="#" >
                                                                            <div class="row align-items-center">
                                                                                <div class="col-auto" style="padding-left: 3px" ><img class="ion_catg" src="<?php echo $this->static_file_site ?>/image/site/icon_catg.png"></div>
                                                                                <div class="col-8" style="padding-right: 3px" >  last -cat </div>
                                                                            </div>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <style>

                    .card-body {
                        padding: 2px 0px 2px 0;
                    }
                    .main_catg
                    {
                        border-top: 1px #dbd9d9 dashed;
                    }


                    .main_catg:last-child {
                        border-bottom: 1px #dbd9d9 dashed;
                    }

                    .row_accordion {

                        background: transparent;
                        border: 0;
                        border-radius: 0;
                        border-top: 1px #dbd9d9 dashed;

                    }

                    .row_accordion  .card-header
                    {
                        background: transparent;
                        padding: 2px 10px 2px 0;
                        border: none;
                        border-radius: 0;
                        border-right: 2px solid transparent;
                        transition: 0.5s;
                    }

                    .row_accordion .card-header:hover {

                        border-right: 2px solid #ff5500;
                    }


                    .row_accordion .btn_open_accordion
                    {
                        background: transparent;
                        border-right: 1px solid #d6d6d6;
                        border-radius: 0;
                        color: #635f5f;
                        font-size: 19px;
                        padding: 3px 16px 0 13px;
                    }



                    .btn.btn_open_accordion.focus, .btn.btn_open_accordion:focus {
                        outline: 0;
                        box-shadow: unset;
                    }

                    .row_accordion .btn_open_accordion i
                    {
                        transition:  0.5s;
                        transform: rotate(-90deg);
                    }

                    .row_accordion .btn_open_accordion.collapsed i
                    {
                        transform: rotate(0deg);
                    }

                    img.ion_catg {
                        width: 14px;
                    }

                    .list_link
                    {

                        color: black;
                    }

                    .list_link ,
                    .list_link:hover
                    {
                        text-decoration: none;

                    }


                    .menu_category {
                        border: 1px solid #d6d6d6;
                        height: 466px;
                        border-top: 2px solid #fe5600;
                        padding-top: 40px;
                        overflow: hidden;
                        overflow-y: auto;
                    }

                </style>


            </div>

        </div>

        <div class="col-lg-9">

<div class="details_mobile">

    <div class="row">
        <div class="col-lg-6">
            <br>
            <br>
            <div class="image_mobile_show">
                <img class="image_user"  id="imagePhone" >
            </div>
        </div>

        <div class="col-lg-6">

            <br>
            <br>
            <div class="details_info_mobile">


                <div class="notePrice">
                    مشمولة في التوصيل المجاني في حال طلبت من الموقع
                </div>

                <div class="choose_color_mobile">
                    <div class="t_d_m">
                        اختيار التفاصيل
                    </div>

                    <div class="color">
                        <span> اللون  </span>
                    </div>
                    <hr>


                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="customRadioInline1" onchange="gstImageFromRadio()" value="https://i.imgur.com/p9S4Gwb.png"" name="customRadioInline1" class="custom-control-input" checked>
                        <label class="custom-control-label"  for="customRadioInline1">   اسود </label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="customRadioInline2"  onchange="gstImageFromRadio()" value="https://i.imgur.com/k8y5Yeo.png"   name="customRadioInline1" class="custom-control-input">
                        <label class="custom-control-label" for="customRadioInline2">  بنفسجي </label>
                    </div>


                </div>

            </div>


        </div>
    </div>

</div>

        </div>

    </div>

</div>


<script>

    gstImageFromRadio();
    function gstImageFromRadio() {
       var value=$("input[type=radio][name='customRadioInline1']:checked").val();
       $('#imagePhone').attr('src',value)
        console.log(value)
    }
    
</script>

<style>
    .image_mobile_show
    {
      text-align: center;
    }
    .image_mobile_show img.image_user {
        height: 350px;
        max-width: 100%;
    }

    .notePrice {
        padding: 5px;
        background: #e5e7f3;
    }

    .price
    {

        font-size: 18px;
        font-weight: bold;
    }
    .t_d_m
    {
        margin-top: 30px;
        font-size: 18px;
        font-weight: bold;
    }

</style>

























<br>
<br>
<br>
<br>